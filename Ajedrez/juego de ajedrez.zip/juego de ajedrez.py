import pygame as p
from Ajedrez import movimientos

ancho = altura = 400  #400 o 500 son buenas opciones para el tablero
dimension = 8  #usualmente la dimension del ajerdrez es de 8 * 8
cuadrado = altura // dimension #los cuadrados del tablero
fps = 15 #será para las animaciones
piezas = {} #lista de las piezas




def cargar_imagenes():
    piezas2 = ["Np","Bp","Nr","Br","Nq","Bq","Nt","Bt","Ba","Na","Nc","Bc",]
    for pieza in piezas2:
        piezas[pieza] = p.transform.scale(p.image.load("piezas/" + pieza + ".png"), (cuadrado, cuadrado))

def graficas():
    p.init()
    pantalla = p.display.set_mode((ancho, altura))
    tiempo = p.time.Clock()
    pantalla.fill(p.Color("white"))
    edj = movimientos.estado_de_juego()
    movimiento_valido = edj.movimientos_validos()
    movimeinto_hecho = False
    cargar_imagenes()
    ejecutar = True
    cuadrado_seleccionado = () #no se escoge un cuadrado al inicio.
    click = [] #tendra en cuenta los clics de los jugadores
    gameover = False
    while ejecutar:
        for i in p.event.get():
            if i.type == p.QUIT:
                ejecutar = False
            elif i.type == p.MOUSEBUTTONDOWN:
                if not gameover:
                    lugar = p.mouse.get_pos() #lugares en el plano del raton(mouse)
                    columna = lugar[0] // cuadrado
                    fila = lugar[1] // cuadrado
                    if cuadrado_seleccionado == (fila, columna):
                        cuadrado_seleccionado = ()
                        click = []
                    else:
                        cuadrado_seleccionado = (fila, columna)
                        click.append(cuadrado_seleccionado)
                    if len(click) == 2:
                        mover = movimientos.movimiento(click[0], click[1], edj.tablero)
                        print(mover.historial())
                        for i in range(len(movimiento_valido)):
                            if mover == movimiento_valido[i]:
                                edj.moverse(movimiento_valido[i])
                                movimeinto_hecho = True
                                cuadrado_seleccionado = ()
                                click = []
                        if not movimeinto_hecho:
                            click = [cuadrado_seleccionado]

            elif i.type == p.KEYDOWN:
                if i.key == p.K_e: #Cuando se presione "E" se desahara el movimiento.
                    edj.quitar_movimiento()
                    movimeinto_hecho = True
                if i.key == p.K_r:
                    edj = movimientos.estado_de_juego()
                    movimiento_valido =edj.movimientos_validos()
                    cuadrado_seleccionado = ()
                    click = []
                    movimeinto_hecho = False


        if movimeinto_hecho:
            movimiento_valido = edj.movimientos_validos()
            movimeinto_hecho = False


        dibujar(pantalla, edj, movimiento_valido, cuadrado_seleccionado)

        if edj.jaque_mate:
            gameover = True
            if edj.movimiento_blanco:
                escribir(pantalla, "Negros ganan por Jaque Mate")
            else:
                escribir(pantalla, "Blancos ganan por Jaque Mate")

        tiempo.tick(fps)
        p.display.flip()


#Esto sera para poder ver los movimientos de las piezas antes de realizarlos.


def resaltar(pantalla, edj, movimiento_valido, cuadrado_seleccionado):
    if cuadrado_seleccionado != ():
        i, j = cuadrado_seleccionado
        if edj.tablero[i][j][0] == ('B' if edj.movimiento_blanco else 'N'):
            #resaltar pieza seleccionada
            s = p.Surface((cuadrado, cuadrado))
            s.set_alpha(100) #transparencia
            s.fill(p.Color("green"))
            pantalla.blit(s, (j * cuadrado, i * cuadrado))






def dibujar(pantalla,edj, movimiento_valido, cuadrado_seleccionado):
    tablero(pantalla)
    dibujar_piezas(pantalla, edj.tablero)
    resaltar(pantalla, edj, movimiento_valido, cuadrado_seleccionado)


def tablero(pantalla):
    global colores
    colores = [p.Color("white"), p.Color("grey")]
    for i in range(dimension): #fila
        for j in range(dimension): #columna
           color = colores[((i + j) % 2)]
           p.draw.rect(pantalla,color,p.Rect(j* cuadrado, i * cuadrado, cuadrado, cuadrado))

def dibujar_piezas(pantalla, tablero):
    for i in range(dimension):
        for j in range(dimension):
            pieza = tablero[i][j]
            if pieza != "--":
                pantalla.blit(piezas[pieza], p.Rect(j*cuadrado, i*cuadrado, cuadrado, cuadrado))





def escribir(pantalla, texto):
    font = p.font.SysFont("Helvitca", 32, True, False)
    objetosDeTexto = font.render(texto, 0, p.Color("Yellow"))
    lugar = p.Rect(0, 0, ancho, altura).move(ancho/2 - objetosDeTexto.get_width()/2, altura/2 - objetosDeTexto.get_height()/2)
    pantalla.blit(objetosDeTexto, lugar)
    objetosDeTexto = font.render(texto, 0, p.Color("Purple"))
    pantalla.blit(objetosDeTexto, lugar.move(2, 2))





graficas()










